Balloon by Vaux for the Bluestick McCoolGuy Ghost

https://vauxhall-fb.straw.page/bluestick

note: his balloon font is RockNRoll One. if you do not have the font on your computer, it will default to MS Gothic.

--------Version History


Ver 1.0 - It exists!